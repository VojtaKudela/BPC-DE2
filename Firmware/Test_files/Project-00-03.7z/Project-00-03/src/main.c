
#ifndef F_CPU
# define F_CPU 16000000  // CPU frequency in Hz required for UART_BAUD_SELECT
#endif

#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>  // Interrupts standard C library for AVR-GCC
#include <uart.h>           // Peter Fleury's UART library

#define SORRY_ARRAY "Sorry!"

int main(void)
{
    uint16_t uart_value;
    uint8_t hello_count = 0;
    uint8_t bye_count = 0;
    uint8_t thanks_count = 0;
    uint8_t pleasure_count = 0;
    uint8_t temp = 0;

    char hello_array[] = "Hello!";
    char bye_array[] = "Bye!";
    char thanks_array[] = "Thanks!";
    char pleasure_array[] = "Pleasure!";

    uart_init(UART_BAUD_SELECT(115200, F_CPU));

    sei();

    while (1)
    {
        uart_value = uart_getc();
        temp = uart_value>>8;
        //uart_putc('0');
        //uart_putc(uart_value);
        uart_putc(temp);
        if ((uart_value>>8) == 0)
        {
            uart_putc('1');
            if (((hello_count+bye_count+thanks_count+pleasure_count)==0)) 
            {
                switch (uart_value)
                {
                    case 'H':
                        hello_count++;
                        break;
                    case 'B':
                        bye_count++;
                        break;
                    case 'T':
                        thanks_count++;
                        break;
                    case 'P':
                        pleasure_count++;
                        break;
                    default:
                        if ((uart_value >= 65)&&(uart_value <= 90))
                        {
                            uart_puts(SORRY_ARRAY);
                            uart_puts("\r\n");
                        }
                        break;
                }
            }
            else
            {
                if (hello_count != 0)
                {
                    if (uart_value == hello_array[hello_count])
                    {
                        hello_count++;

                        if (hello_count > 5)
                        {
                            uart_puts(bye_array);
                            uart_puts("\r\n");
                            hello_count = 0;
                        }
                    }
                    else
                    {
                        uart_puts(SORRY_ARRAY);
                        uart_puts("\r\n");
                        hello_count = 0;
                    }
                }
                else if (bye_count != 0)
                {
                    if (uart_value == bye_array[bye_count])
                    {
                        bye_count++;

                        if (bye_count > 3)
                        {
                            uart_puts(hello_array);
                            uart_puts("\r\n");
                            bye_count = 0;
                        }
                    }
                    else
                    {
                        uart_puts(SORRY_ARRAY);
                        uart_puts("\r\n");
                        bye_count = 0;
                    }
                }
                else if (thanks_count != 0)
                {
                    if (uart_value == thanks_array[thanks_count])
                    {
                        thanks_count++;

                        if (thanks_count > 6)
                        {
                            uart_puts(pleasure_array);
                            uart_puts("\r\n");
                            thanks_count = 0;
                        }
                    }
                    else
                    {
                        uart_puts(SORRY_ARRAY);
                        uart_puts("\r\n");
                        thanks_count = 0;
                    }
                }
                else
                {
                    if (uart_value == pleasure_array[pleasure_count])
                    {
                        pleasure_count++;

                        if (pleasure_count > 8)
                        {
                            uart_puts(thanks_array);
                            uart_puts("\r\n");
                            pleasure_count = 0;
                        }
                    }
                    else
                    {
                        uart_puts(SORRY_ARRAY);
                        uart_puts("\r\n");
                        pleasure_count = 0;
                    }
                }
            }
        }
    }

    return 0;
}