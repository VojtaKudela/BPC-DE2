
#ifndef F_CPU
# define F_CPU 16000000  // CPU frequency in Hz required for UART_BAUD_SELECT
#endif

#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>  // Interrupts standard C library for AVR-GCC
#include <uart.h>           // Peter Fleury's UART library
#include <timer.h>
#include <stdlib.h>         // C library. Needed for number conversions

volatile uint8_t update_data = 0;

struct time_packet {
   uint8_t year;
   uint8_t month;
   uint8_t date;
   uint8_t day;
   uint8_t hour;
   uint8_t minute;
   uint8_t second;
} new_time;

struct reg_packet {
   uint8_t temp_val;
   uint8_t temp_hys;
   uint8_t hum_val;
   uint8_t hum_hys;
   uint8_t soil_val;
   uint8_t soil_hys;
   uint8_t ilu_100;
   uint8_t ilu_1;
} new_reg;

int main(void)
{
    uint8_t new_data = 0; // 0 - none, 1 - reg, 2 - time
    uint8_t data_count = 0;
    uint16_t uart_data;

    char string[4];

    // Struct contains receive time data.
    new_time.year = 0x00;
    new_time.month = 0x00;
    new_time.date = 0x00;
    new_time.day = 0x00;
    new_time.hour = 0x00;
    new_time.minute = 0x00;
    new_time.second = 0x00;

    // Struct contains receive regulation data.
    new_reg.temp_val = 0x00;
    new_reg.temp_hys = 0x00;
    new_reg.hum_val = 0x00;
    new_reg.hum_hys = 0x00;
    new_reg.soil_val = 0x00;
    new_reg.soil_hys = 0x00;
    new_reg.ilu_100 = 0x00;
    new_reg.ilu_1 = 0x00;


    uart_init(UART_BAUD_SELECT(9600, F_CPU));

    sei();

    while (1)
    {
        uart_data = uart_getc();

        if ((uart_data>>8)==0)
        {
            uart_data = (uart_data&0x00ff);
            //uart_putc(uart_data);
            if (new_data == 0)
            {
                if (uart_data == 'T')
                {
                    //uart_putc('#');
                    new_data = 2;
                    data_count++;
                }
                else if (uart_data == 'R')
                {
                    //uart_putc('|');
                    new_data = 1;
                    data_count++;
                }
            }
            else if (new_data == 1) // Receive regulation data
            {
                switch (data_count)
                    {
                        case 1:
                            new_reg.temp_val = uart_data;
                            break;
                        case 2:
                            new_reg.temp_hys = uart_data;
                            break;
                        case 3:
                            new_reg.hum_val = uart_data;
                            break;
                        case 4:
                            new_reg.hum_hys = uart_data;
                            break;
                        case 5:
                            new_reg.soil_val = uart_data;
                            break;
                        case 6:
                            new_reg.soil_hys = uart_data;
                            break;
                        case 7:
                            new_reg.ilu_100 = uart_data;
                            break;
                        default:
                            new_reg.ilu_1 = uart_data;
                            break;
                    }
                    
                data_count++;
                
            }
            else if (new_data == 2) // Receive time data
            {
                    switch (data_count)
                    {
                        case 1:
                            new_time.year = uart_data;
                            break;
                        case 2:
                            new_time.month = uart_data;
                            break;
                        case 3:
                            new_time.date = uart_data;
                            break;
                        case 4:
                            new_time.day = uart_data;
                            break;
                        case 5:
                            new_time.hour = uart_data;
                            break;
                        case 6:
                            new_time.minute = uart_data;
                            break;
                        default:
                            new_time.second = uart_data;
                            break;
                    }
                data_count++;
            }

            if ((new_data == 1) & (data_count > 8))
            {
                data_count = 0;
                new_data = 0;

                uart_puts("\r\n");
                itoa(new_reg.temp_val, string, 10);
                uart_puts(string);
                uart_puts(" ");

                itoa(new_reg.temp_hys, string, 10);
                uart_puts(string);
                uart_puts(", ");

                itoa(new_reg.hum_val, string, 10);
                uart_puts(string);
                uart_puts(" ");

                itoa(new_reg.hum_hys, string, 10);
                uart_puts(string);
                uart_puts(", ");

                itoa(new_reg.soil_val, string, 10);
                uart_puts(string);
                uart_puts(" ");

                itoa(new_reg.soil_hys, string, 10);
                uart_puts(string);
                uart_puts(", ");

                itoa(new_reg.ilu_100, string, 10);
                uart_puts(string);

                itoa(new_reg.ilu_1, string, 10);
                uart_puts(string);
            }
            else if ((new_data == 2) & (data_count > 7))
            {
                data_count = 0;
                new_data = 0;

                uart_puts("\r\n");
                itoa(new_time.year, string, 10);
                uart_puts(string);
                uart_puts(" ");

                itoa(new_time.month, string, 10);
                uart_puts(string);
                uart_puts(" ");

                itoa(new_time.date, string, 10);
                uart_puts(string);
                uart_puts(" ");

                itoa(new_time.day, string, 10);
                uart_puts(string);
                uart_puts(" ");

                itoa(new_time.hour, string, 10);
                uart_puts(string);
                uart_puts(" ");

                itoa(new_time.minute, string, 10);
                uart_puts(string);
                uart_puts(" ");

                itoa(new_time.second, string, 10);
                uart_puts(string);
            }
        }
    }

    return 0;
}