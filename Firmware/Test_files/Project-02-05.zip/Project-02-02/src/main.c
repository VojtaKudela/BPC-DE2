
// Contain necessary includes and defines
// CPU frequency in Hz required for UART_BAUD_SELECT
#ifndef F_CPU
# define F_CPU 16000000  
#endif

// Includes
#include <avr/io.h>
#include <heater.h>
#include <soil.h>
#include <pwm.h>
#include <trop_lib.h>
#include <preper_data.h>
#include <util/twi.h>
#include <twi.h>
#include <avr/interrupt.h>
#include <uart.h>
#include <timer.h>
#include <adc.h>

// Global variables
volatile uint8_t update_data = 0;

// Main loop
int main(void)
{
    uint16_t ilu_set;   // Auxiliary variable for storing the 16-bit lighting setpoint.
    uint8_t  new_data;   // Carry information about type of new data 0 - none, 1 - reg, 2 - time
    uint8_t  data_count; // Number of receive bytes
    uint16_t uart_data; // Receive uart_byte

    // Main clock
    TIM1_ovf_1sec();
    TIM1_ovf_enable();

    // ADC clock
    TIM2_ovf_16ms();
    TIM2_ovf_enable();

    // ADC start
    ADC_setup();

    startup();

    while (1)
    {
        uart_data = uart_getc();

        if ((uart_data>>8)==0)
        {
            uart_data = (uart_data&0x00ff);

            // First letter carry information about type of data
            if (new_data == 0)
            {
                if (uart_data == 'T')
                {
                    new_data = 2;
                    data_count++;
                }
                else if (uart_data == 'R')
                {
                    new_data = 1;
                    data_count++;
                }
            }
            // Receive regulation data
            else if (new_data == 1)
            {
                receive_R_data(uart_data,data_count);       
                data_count++;    
            }
             // Receive time data
            else if (new_data == 2)
            {
                receive_T_data(uart_data,data_count); 
                data_count++;
            }
             
            if ((new_data == 1) & (data_count > 8))
            {
                data_count = 0;
                new_data = 0;

            }
            // Apply time value
            else if ((new_data == 2) & (data_count > 7))
            {
                data_count = 0;
                new_data = 0;
                write_rtc_data();  // Data are send via I2C
            }
        }

        if (update_data == 1)
        {
            // Read RTC and DHT data
            read_rtc_data();
            read_dht_data();

            // Control of PWM
            ilu_set = rg.ilu_100*100 + rg.ilu_1;
            PWM_control(PD_ilu(dp.lux),ilu_set,5);

            // Control ventil
            SOIL_control(REG_PORT, VALV, PD_soil(dp.soil), rg.soil_val, rg.soil_hys);

            // Control heater, fan and inhalator
            HEATER_FAN_control(REG_PORT, HEAT, REG_PORT, COOL, REG_PORT, INHA, PD_round(dp.temp_int,dp.temp_dec), 
                                rg.temp_val, rg.temp_hys, PD_round(dp.hum_int,dp.hum_dec), rg.hum_val, rg.hum_hys);

            // Send updated data via UART
            transmit_uart_data();

            // Update checked
            update_data = 0; 
        }
    }

    return 0;
}

ISR(TIMER1_OVF_vect)
{
    update_data = 1;
}

ISR(TIMER2_OVF_vect)
{
    static uint8_t counter = 0;
    counter++;

    if (counter >= 6) 
    {
        counter = 0;
        ADC_switchport();
        ADC_startconversion();
    }
}

ISR(ADC_vect)
{
    if (ADMUX & (1 << MUX0)) 
    {
        dp.soil = ADC; // Connect to A3
    } 
        else 
    {
        dp.lux = ADC; // Connect to A2
    }
}