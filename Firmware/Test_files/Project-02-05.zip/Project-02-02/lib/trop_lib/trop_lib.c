/* 
 * Preper_Data libary
 * (c) Antonin Putala 2024
 *
 * Developed using PlatformIO and AVR 8-bit Toolchain 3.6.2.
 * Tested on Arduino Uno board and ATmega328P, 16 MHz.
 */

// -- Includes -------------------------------------------------------
#include <trop_lib.h>

// -- Function definitions -------------------------------------------
/*
 * Function: startup
 * Purpose:  Performs the necessary settings and initializations.
 * Input(s): None
 * Returns:  None
 */
void startup(void)
{
    // Last transmitted symbol
    dp.mask = '\n';

    uart_init(UART_BAUD_SELECT(BAUDRATE, F_CPU));
    twi_init();

    // Initialize regulation pin
    HEATER_init(REG_PORT-1, HEAT); // address of PORT - 1 is adress of DDR
    FAN_init(REG_PORT-1, COOL);
    INH_init(REG_PORT-1, INHA);
    SOIL_init(REG_PORT-1, VALV);

    // Initialization of PWM
    PWM_enable();
    PWM_set_duty(0);

    // Default data
    rg.temp_val = 20;
    rg.temp_hys = 2;
    rg.hum_val = 50;
    rg.hum_hys = 5;
    rg.soil_val = 50;
    rg.soil_hys = 5;
    rg.ilu_100 = 1;
    rg.ilu_1 = 0;

    // Global interupt enable
    sei();
}

/*
 * Function: write_rtc_data
 * Purpose:  It uses I2C to set the time on the RTC..
 * Input(s): None
 * Returns:  None
 */
void write_rtc_data(void)
{
    twi_start();

    if (twi_write((RTC_ADR<<1) | TWI_WRITE) == 0) // RTC I2C address
    {   
        twi_write(RTC_SEC_MEM);         // Register to start reading
        twi_write(rc.second); 
        twi_write(rc.minute); 
        twi_write(rc.hour); 
        twi_write(rc.day);
        twi_write(rc.date);
        twi_write(rc.month);
        twi_write(rc.year);
    }

    twi_stop();
}

/*
 * Function: read_rtc_data
 * Purpose:  It reads the time from the RTC using I2C.
 * Input(s): None
 * Returns:  None
 */
void read_rtc_data(void)
{
    twi_start();
    if (twi_write((RTC_ADR<<1) | TWI_WRITE) == 0) 
    {
        twi_write(RTC_SEC_MEM);
        twi_stop();

        twi_start();
        twi_write((RTC_ADR<<1) | TWI_READ);
        dp.second = twi_read(TWI_ACK);
        dp.minute = twi_read(TWI_ACK);
        dp.hour = twi_read(TWI_ACK);
        dp.day = twi_read(TWI_ACK);
        dp.date = twi_read(TWI_ACK);
        dp.month = twi_read(TWI_ACK);
        dp.year = twi_read(TWI_NACK);
    }
    twi_stop();
}

/*
 * Function: read_dth_data
 * Purpose:  It reads temperature and pressure from the sensor using I2C.
 * Input(s): None
 * Returns:  None
 */
void read_dht_data(void)
{
    uint8_t hum_raw[2], temp_raw[2];
    uint8_t cumsum;
    
    twi_start();

    if (twi_write((DHT_ADR<<1) | TWI_WRITE) == 0) // Start communication with DHT
    {
        twi_write(DHT_HUM_MEM);                   // Point to humidity register
        twi_stop();

        twi_start();
        twi_write((DHT_ADR << 1) | TWI_READ);    // Read operation
        hum_raw[0] = twi_read(TWI_ACK);          // Read high byte of humidity
        hum_raw[1] = twi_read(TWI_ACK);          // Read low byte of humidity
        temp_raw[0] = twi_read(TWI_ACK);         // Read high byte of temperature
        temp_raw[1] = twi_read(TWI_ACK);         // Read low byte of temperature
        cumsum      = twi_read(TWI_NACK);        // Read cumsum
        
        // Are received data correct?
        if ((hum_raw[1] + temp_raw[1] + hum_raw[0] + temp_raw[0]) == cumsum)                                    
        {
            dp.hum_int = hum_raw[0];
            dp.hum_dec = hum_raw[1];
            dp.temp_int = temp_raw[0];
            dp.temp_dec = temp_raw[1];
        }
    }
    twi_stop();
}

/*
 * Function: transmit_uart_data
 * Purpose:  Sends data via UART.
 * Input(s): None
 * Returns:  None
 */
void transmit_uart_data(void)
{
    // Local variables
    uint8_t lux_rec;
    uint8_t soil_rec;

    // Preper transmit value
    lux_rec = PD_uart(dp.lux,dp.mask);
    soil_rec = PD_uart(dp.soil,dp.mask);

    // Send updated data via UART
    uart_putc(dp.year);
    uart_putc(dp.month);
    uart_putc(dp.date);
    uart_putc(dp.day);
    uart_putc(dp.hour);
    uart_putc(dp.minute);
    uart_putc(dp.second);
    uart_putc(dp.hum_int);
    uart_putc(dp.hum_dec);
    uart_putc(dp.temp_int);
    uart_putc(dp.temp_dec);
    uart_putc(lux_rec);
    uart_putc(soil_rec);
    uart_putc(dp.mask);
}

/*
 * Function: receive_R_data
 * Purpose:  Saves regulation data from UART.
 * Input(s): uart_data  - Received data from UART
 *           data_count - What is the byte number?
 * Returns:  None
 */
void receive_R_data(uint8_t uart_data, uint8_t data_count)
{
    switch (data_count)
    {
        case 1:
            rg.temp_val = uart_data;
            break;
        case 2:
            rg.temp_hys = uart_data;
            break;
        case 3:
            rg.hum_val = uart_data;
            break;
        case 4:
            rg.hum_hys = uart_data;
            break;
        case 5:
            rg.soil_val = uart_data;
            break;
        case 6:
            rg.soil_hys = uart_data;
            break;
        case 7:
            rg.ilu_100 = uart_data;
            break;
        default:
            rg.ilu_1 = uart_data;
            break;
    }
}

/*
 * Function: receive_T_data
 * Purpose:  Saves time data from UART.
 * Input(s): uart_data  - Received data from UART
 *           data_count - What is the byte number?
 * Returns:  None
 */
void receive_T_data(uint8_t uart_data, uint8_t data_count)
{
    switch (data_count)
    {
        case 1:
            rc.year = uart_data;
            break;
        case 2:
            rc.month = uart_data;
            break;
        case 3:
            rc.date = uart_data;
            break;
        case 4:
            rc.day = uart_data;
            break;
        case 5:
            rc.hour = uart_data;
            break;
        case 6:
            rc.minute = uart_data;
            break;
        default:
            rc.second = uart_data;
            break;
    }
}