#ifndef TL_H
# define TL_H
/* 
 * Trop_lib library
 * (c) Vit_Janos, Antonin_Putala 2024
 *
 * Developed using PlatformIO and AVR 8-bit Toolchain 3.6.2.
 * Tested on Arduino Uno board and ATmega328P, 16 MHz.
 */

/**
 * @file 
 * @defgroup Trop_lib library <trop_lib.h>
 * @code #include <trop_lib.h> @endcode
 *
 * @brief The library with special function.
 *
 * The library contains functions for Tropical plants.
 *
 * @copyright (c) Vit Janos, Antonin Putala 2024
 * @{
 */

/* Includes -----------------------------------------------*/
#include <avr/io.h>
#include <preper_data.h>
#include <util/twi.h>
#include <twi.h>
#include <avr/interrupt.h>
#include <uart.h>
#include <heater.h>
#include <soil.h>
#include <pwm.h>

// RTC Definitions
#define RTC_ADR 0x68
#define RTC_SEC_MEM 0x00
#define RTC_MIN_MEM 0x01
#define RTC_HOUR_MEM 0x02
#define RTC_DAY_MEM 0x03
#define RTC_DATE_MEM 0x04
#define RTC_MONTH_MEM 0x05
#define RTC_YEAR_MEM 0x06

// DHT Sensor Definitions
#define DHT_ADR 0x5c
#define DHT_HUM_MEM 0
#define DHT_TEMP_MEM 2

// UART definition
#define BAUDRATE 9600

// Defines for regulation
#define HEAT PB0
#define COOL PB1
#define INHA PB2
#define VALV PB3
#define REG_PORT &PORTB

/* Function prototypes ------------------------------------*/
/**
 * @brief   Performs the necessary settings and initializations.
 * @param   None
 * @return  None
 */
void startup(void);

/**
 * @brief   It reads the time from the RTC using I2C.
 * @param   None
 * @return  None
 */
void write_rtc_data(void);

/**
 * @brief   It uses I2C to set the time on the RTC.
 * @param   None
 * @return  None
 */
void read_rtc_data(void);

/**
 * @brief   It reads temperature and pressure from the sensor using I2C.
 * @param   None
 * @return  None
 */
void read_dht_data(void);

/**
 * @brief   Sends data via UART.
 * @param   None
 * @return  None
 */
void transmit_uart_data(void);

/**
 * @brief   Saves regulation data from UART.
 * @param   uart_data  Received data from UART
 * @param   data_count What is the byte number?
 * @return  None
 */
void receive_R_data(uint8_t uart_data, uint8_t data_count);

/**
 * @brief   Saves time data from UART.
 * @param   uart_data  Received data from UART
 * @param   data_count What is the byte number?
 * @return  None
 */
void receive_T_data(uint8_t uart_data, uint8_t data_count);

// Data packet, preper data to transmit
struct data_packet {
   volatile uint8_t year;
   volatile uint8_t month;
   volatile uint8_t date;
   volatile uint8_t day;
   volatile uint8_t hour;
   volatile uint8_t minute;
   volatile uint8_t second;
   volatile uint8_t hum_int;
   volatile uint8_t hum_dec;
   volatile uint8_t temp_int;
   volatile uint8_t temp_dec;
   volatile uint16_t lux;
   volatile uint16_t soil;
   volatile uint8_t mask;
} dp;

// Receive data from UART, time settings
struct rec_time {
   volatile uint8_t year;
   volatile uint8_t month;
   volatile uint8_t date;
   volatile uint8_t day;
   volatile uint8_t hour;
   volatile uint8_t minute;
   volatile uint8_t second;
} rc;

// Receive data from UART, regulation
struct rec_reg {
   volatile uint8_t temp_val;
   volatile uint8_t temp_hys;
   volatile uint8_t hum_val;
   volatile uint8_t hum_hys;
   volatile uint8_t soil_val;
   volatile uint8_t soil_hys;
   volatile uint8_t ilu_100;
   volatile uint8_t ilu_1;
} rg;

/** @} */
#endif