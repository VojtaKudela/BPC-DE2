
#ifndef F_CPU
# define F_CPU 16000000  // CPU frequency in Hz required for UART_BAUD_SELECT
#endif

#include "heater.h"
#include <util/delay.h>
#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>  // Interrupts standard C library for AVR-GCC
#include <uart.h>           // Peter Fleury's UART library
#include <stdlib.h>         // C library. Needed for number conversions

#define HEAT PB0
#define COOL PB1
#define INHA PB2
#define HC_PORT &PORTB

int main(void)
{
    // Local variables
    char string[4]; 
    uint8_t down = 0;
    uint8_t down_hum = 0;

    // Initialization of UART
    uart_init(UART_BAUD_SELECT(9600, F_CPU));

    // Inicializace pinů pro topení a větráček
    HEATER_init(HC_PORT-1, HEAT); // address of PORT - 1 is adress of DDR
    FAN_init(HC_PORT-1, COOL);
    INH_init(HC_PORT-1, INHA);

    // Proměnné pro teplotu a nastavení
    int8_t current_temp = 20; // aktuální teplota
    int8_t setpoint_temp = 25;     // požadovaná teplota
    int8_t hyst_temp = 2;    // hystereze

    // Variable for humidity and settings
    int8_t current_hum = 40; // aktuální teplota
    int8_t setpoint_hum = 50;     // požadovaná teplota
    int8_t hyst_hum = 5;    // hystereze

    // Allow interupts
    sei();

    // Hlavní smyčka
    while (1)
    {
        // Ovládání topení a větráčku na základě teploty
        HEATER_FAN_control(HC_PORT, HEAT, HC_PORT, COOL, HC_PORT, INHA, current_temp, setpoint_temp, hyst_temp, current_hum, setpoint_hum, hyst_hum);

        itoa(current_temp, string, 10);
        uart_puts(string);
        uart_putc(' ');
        itoa(current_hum, string, 10);
        uart_puts(string);
        uart_putc('\n');


        // Simulace změny teploty (pro testování)
        _delay_ms(1000);

        if (down == 0)
        {
            current_temp++;
        }
        else
        {
            current_temp--;
        }

        if (down_hum == 0)
        {
            current_hum++;
        }
        else
        {
            current_hum--;
        }

        if ((current_temp > 30) & (down == 0))
        {
            down = 1;
        }
        else if ((current_temp < 20) & (down == 1))
        {
            down = 0;
        }

        if ((current_hum > 65) & (down_hum == 0))
        {
            down_hum = 1;
        }
        else if ((current_hum < 40) & (down_hum == 1))
        {
            down_hum = 0;
        }
    }

    return 0;
}