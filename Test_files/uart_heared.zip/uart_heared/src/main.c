
/* Defines -----------------------------------------------------------*/
#ifndef F_CPU
# define F_CPU 16000000  // CPU frequency in Hz required for UART_BAUD_SELECT
#endif


/* Includes ----------------------------------------------------------*/
#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>  // Interrupts standard C library for AVR-GCC
#include <uart.h>           // Peter Fleury's UART library
#include <stdlib.h>         // C library. Needed for number conversions
#include <gpio.h>

#define LED PB0
#define LED_PORT &PORTB

int main(void)
{
    uint8_t uart_data;

    GPIO_mode_output(LED_PORT-1,PD0);
    GPIO_write_high(LED_PORT,LED);

    uart_init(UART_BAUD_SELECT(9600, F_CPU));

    sei();

    while (1)
    {
        uart_data = uart_getc();

        if ((uart_data>>8)==0)
        {
            if (uart_data=='O')
            {
                GPIO_write_low(LED_PORT,LED);
            }
            else if (uart_data=='C')
            {
                GPIO_write_high(LED_PORT,LED);
            }
        }
    }

    return 0;
}