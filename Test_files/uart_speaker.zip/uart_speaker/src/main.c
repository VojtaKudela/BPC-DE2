
/* Defines -----------------------------------------------------------*/
#ifndef F_CPU
# define F_CPU 16000000  // CPU frequency in Hz required for UART_BAUD_SELECT
#endif


/* Includes ----------------------------------------------------------*/
#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>  // Interrupts standard C library for AVR-GCC
#include "timer.h"          // Timer library for AVR-GCC
#include <uart.h>           // Peter Fleury's UART library
#include <stdlib.h>         // C library. Needed for number conversions

volatile uint8_t update_data = 0;

int main(void)
{
    char output = 'A';
    uint8_t ncyc = 0;

    uart_init(UART_BAUD_SELECT(9600, F_CPU));

    TIM1_ovf_1sec();
    TIM1_ovf_enable();

    sei();

    while (1)
    {
        if (update_data == 1)
        {
            uart_putc(output+ncyc);
            ncyc++;
            ncyc %= 26;
            update_data = 0;
        }
    }

    return 0;
}

ISR (TIMER1_OVF_vect)
{
    update_data = 1;
}