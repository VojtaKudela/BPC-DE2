
#ifndef F_CPU
# define F_CPU 16000000  // CPU frequency in Hz required for UART_BAUD_SELECT
#endif

#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>  // Interrupts standard C library for AVR-GCC
#include <uart.h>           // Peter Fleury's UART library
#include <timer.h>

volatile uint8_t update_data = 0;

struct data_packet {
   uint8_t year;
   uint8_t month;
   uint8_t date;
   uint8_t day;
   uint8_t hour;
   uint8_t minute;
   uint8_t second;
   uint8_t hum_int;
   uint8_t hum_dec;
   uint8_t temp_int;
   uint8_t temp_dec;
   uint8_t lux;
   uint8_t soil;
   uint8_t mask;
} dp;

int main(void)
{
    dp.year = 0x24;
    dp.month = 0x91;
    dp.date = 0x13;
    dp.day = 0x03;
    dp.hour = 0x09;
    dp.minute = 0x59;
    dp.second = 0x00;
    dp.hum_int = 0x50;
    dp.hum_dec = 0x01;
    dp.temp_int = 0x25;
    dp.temp_dec = 0x02;
    dp.lux = 0x40;
    dp.soil = 0x41;
    dp.mask = 0xff;


    uart_init(UART_BAUD_SELECT(9600, F_CPU));
    
    TIM1_ovf_262ms();
    TIM1_ovf_enable();

    sei();

    while (1)
    {
        if (update_data == 1)
        {
            uart_putc(dp.year);
            uart_putc(dp.month);
            uart_putc(dp.date);
            uart_putc(dp.day);
            uart_putc(dp.hour);
            uart_putc(dp.minute);
            uart_putc(dp.second);
            uart_putc(dp.hum_int);
            uart_putc(dp.hum_dec);
            uart_putc(dp.temp_int);
            uart_putc(dp.temp_dec);
            uart_putc(dp.lux);
            uart_putc(dp.soil);
            uart_putc(dp.mask);
            update_data = 0;
        }
    }

    return 0;
}

ISR(TIMER1_OVF_vect)
{
    update_data = 1;
}